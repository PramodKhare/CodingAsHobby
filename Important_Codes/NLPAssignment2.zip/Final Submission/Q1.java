/**
 * NLP CS6120 Assignment 2 - CFG - Chomsky Context Free Grammer
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Random;
import java.util.TreeMap;

/**
 * @author Pramod Khare Generating sentences from a grammar
 */
public class Q1 {

  // This flag is used while reading grammar file to mark the start and end of
  // vocabulary section, all other part of grammar file is considered as grammar
  public static boolean isVocabularySection = false;

  /* A Randomised bag for grammar rules */
  public static Map<String, RandomCollection<String>> grammarMap = new HashMap<String, RandomCollection<String>>();

  /* A Randomised bag for grammar rules */
  public static Map<String, RandomCollection<String>> vocabularyMap = new HashMap<String, RandomCollection<String>>();

  /* Total number of lines to generate using the grammar */
  public static int linesToGenerate;

  /* Expanded Grammar Rule */
  public static List<String> sentenceRule = new LinkedList<String>();

  /* Pattern for splitting the lines */
  public final static String regexPattern = "\\s+";

  public Q1() {
  }

  /**
   * @param args
   *          Should provide the grammer file and count of lines to generate
   * @throws IOException
   */
  // Basic Algorithm -->
  // 1) First read the grammar file which contains both Human-written grammer
  // and vocabulary and load it into Vocabulary and Grammar maps resp which are
  // Randomised bag of objects structures.
  // 2) For each line to be generated (i.e. for-loop for given number of lines
  // to be generated)
  // - Start with first LHS symbol => START symbol
  // - For each symbol in expanded symbol-rule -> look up from grammar map
  // - and check if there any left-recursive rule expansion available
  // - If no expansion is available then its a terminal, ignore it i.e. don't
  //    change it
  // - and recursively expand it until there is no LHS found in the grammar map
  // - Then iterate again over the sentenceRule -> for each Terminal symbol ->
  // get the word from vocabulary and create a new line altogether.

  public static void main(String[] args) throws IOException {
    if (args.length != 2) {
      System.err
          .println("Please provide <grammer_file> and <count_of_lines_to_output>");
      System.exit(-1);
    }

    // First read the grammar file which contains both Human-written grammar and
    // vocabulary and load it into Vocabulary and Grammar maps
    loadGrammarAndVocabulary(args[0]);
    linesToGenerate = Integer.parseInt(args[1]);

    // for loop for given number of lines to be generated
    // START == LHS -- look up from grammar map
    sentenceRule.add("START");

    for (int i = 0; i < linesToGenerate; i++) {
      // and recursively expand it until there is no LHS found in the grammar
      // map, meaning all symbols in the generated sentence are Terminals
      expandSentenceRuleUsingGrammarRules();
      // Then iterate over all the Terminals in the expanded sentences
      // and create a new line altogether.
      System.out.println(generateSentencesUsingSentenceRule());
    }
  }

  /**
   * Using the expanded sentence using grammar rules - replace each symbol with
   * a word from vocabulary
   */
  private static String generateSentencesUsingSentenceRule() {
    RandomCollection<String> rc = null;
    StringBuffer outputSentence = new StringBuffer();
    for (String symbol : sentenceRule) {
      rc = vocabularyMap.get(symbol);
      if (rc != null) {
        outputSentence.append(rc.next()).append(" ");
      } else {
        outputSentence.append(symbol).append(" ");
      }
    }
    return outputSentence.toString().trim();
  }

  private static void expandSentenceRuleUsingGrammarRules() {
    // System.out.println("Expanding the rules - ");
    // For each String node in sentenceRule Linked-List - check if there is any
    // other recursive expansion available in Randomised collection
    for (int i = 0; i < sentenceRule.size();) {
      // Take each node in list and check if it has a substitution possible
      // from the grammar map
      String symbol = sentenceRule.get(i);
      // System.out.println(symbol);
      if (null == grammarMap.get(symbol)) {
        // Meaning its a Terminal symbol then proceed to the next symbol
        i++;
        continue;
      }
      String RHSSymbol = grammarMap.get(symbol).next();
      String[] tkn = RHSSymbol.trim().split(regexPattern);
      // Remove the current symbol first and then add the new expanded sysmbols
      sentenceRule.remove(i);
      for (int j = 0; j < tkn.length; j++) {
        sentenceRule.add(i + j, tkn[j]);
      }
    }
  }

  public static void loadGrammarAndVocabulary(final String grammerFileName)
      throws IOException {
    final File inputFile = new File(grammerFileName);

    if (!inputFile.exists()) {
      System.err.println("Grammar file doesn't exists!! :(");
      System.exit(-1);
    }

    BufferedReader br = null;
    StringBuffer RHSValue = null;
    String line = null;
    String[] tokens = null;
    int probability;
    RandomCollection<String> rc = null;
    try {
      br = new BufferedReader(new FileReader(inputFile));

      // Read input file line by line
      while (null != (line = br.readLine())) {
        line = line.trim();
        if (line.length() == 0) {
          continue;
        }
        if (line.startsWith("#")) {
          if (line.contains("Vocabulary section")) {
            isVocabularySection = true;
          } else if (line.contains("S2 tag bigram model")
              || line.contains("Beginning of human-written grammar")) {
            isVocabularySection = false;
          }
          continue;
        }
        // System.out.println(line);
        // Split the line across space characters
        // save the probability and LHS and RHS into respective maps
        tokens = line.split(regexPattern);
        probability = Integer.parseInt(tokens[0]);

        // If its a vocabulary section then add terms to vocabulary map
        if (isVocabularySection) {
          rc = vocabularyMap.get(tokens[1]);
          if (null == rc) {
            rc = new RandomCollection<String>();
            rc.add(probability, tokens[2]);
            vocabularyMap.put(tokens[1], rc);
          } else {
            rc.add(probability, tokens[2]);
          }
        } else {
          // If its a grammar section then add terms to grammar map
          rc = grammarMap.get(tokens[1]);
          RHSValue = new StringBuffer();
          for (int i = 2; i < tokens.length; i++) {
            RHSValue.append(tokens[i]).append(" ");
          }
          if (null == rc) {
            rc = new RandomCollection<String>();
            rc.add(probability, RHSValue.toString().trim());
            grammarMap.put(tokens[1], rc);
          } else {
            rc.add(probability, RHSValue.toString().trim());
          }
        }
      }
    } catch (final IOException e) {
      e.printStackTrace();
    } finally {
      try {
        if (br != null) {
          br.close();
        }
      } catch (final IOException ex) {
        ex.printStackTrace();
      }
    }
  }
}

/**
 * Influenced from
 * http://stackoverflow.com/questions/6409652/random-weighted-selection
 * -java-framework
 * 
 * @param <E>
 */
class RandomCollection<E> {
  private final NavigableMap<Integer, E> map = new TreeMap<Integer, E>();
  private final Random random;
  private int total = 0;

  public RandomCollection() {
    this(new Random());
  }

  public RandomCollection(Random random) {
    this.random = random;
  }

  public void add(int weight, E result) {
    if (weight <= 0)
      return;
    total += weight;
    map.put(total, result);
  }

  public E next() {
    int value = (int) (random.nextDouble() * total);
    return map.ceilingEntry(value).getValue();
  }
}
