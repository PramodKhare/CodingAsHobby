Problem Statement:
Create a transducer that maps numbers in the range 0 - 999,999,999 represented as digit strings to their English read form, 
e.g.:
1 -> one
1 1 -> eleven
1 1 1 -> one hundred eleven
1 1 1 1 -> one thousand one hundred eleven
1 1 1 1 1 -> eleven thousand one hundred eleven
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++

TESTING :: How to test your FST: 
1) create a unit-FST or FST which does nothing to its input... inputFST.txt
fstcompile --isymbols=ascii.syms --osymbols=ascii.syms inputFST.txt inputFST.fst

fstdraw --isymbols=ascii.syms --osymbols=ascii.syms -portrait inputFST.fst | dot -Tjpg >inputFST.jpg

e.g. 
0 1 1 1
1 2 9 9
2 3 5 5
3
++++++++++
And Compose inputFST with your FST -- to get the required output.

fstcompose inputFST.fst 9-digits.fst | fstproject --project_output | fstrmepsilon | fstprint --isymbols=words.syms --osymbols=words.syms

++++++++++++++++++++++++++++++++
Attempt 1: 

Get Numbers 0-9 To words --> Implemented 0-9.fst --> fstcompile --isymbols=ascii.syms --osymbols=words.syms 0-9.txt 0-9.fst

>> fstcompose inputFST.fst 9-digits.fst | fstproject --project_output | fstrmepsilon | fstprint --isymbols=words.syms --osymbols=words.syms

Outputs -> each digit value -- in words

e.g. 	11 - one one
		3456 - three four five six
		
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

NOTE 1: 
One way to solve the problem can be after every three digit group add -- million FST (two node FST with one of them is epsilon transition and other is <epsilon> to million word, similarly for thousand).
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Other important thing :: 
First Construct the 0-999 transducer and copy it thrice... with above "NOTE 1".
Similarly, first construct 0-9, 10-19, 20-90 transducers and union them to get 0-99 transducer.
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

In order to construct 0-19 transducer ::
fstunion 0-9.fst 10-19.fst  |  fstrmepsilon | fstdeterminize | fstminimize >0-19.fst
fstdraw --isymbols=ascii.syms --osymbols=words.syms -portrait 0-19.fst | dot -Tjpg >0-19.jpg
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

In order to create 20-99 transducer :: 
Concatenate 20-90 with 1-9 ::. 
fstconcat 20-90.fst 1-9.fst | fstrmepsilon | fstdeterminize | fstminimize >20-99.fst
fstdraw --isymbols=ascii.syms --osymbols=words.syms -portrait 20-99.fst | dot -Tjpg >20-99.jpg
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

To get 0-99 transducer ::  
Then take the union with 0-19 and 20-99 to get 0-99 transducer.
fstunion 0-19.fst 20-99.fst  |  fstrmepsilon | fstdeterminize | fstminimize >0-99.fst
fstdraw --isymbols=ascii.syms --osymbols=words.syms -portrait 0-99.fst | dot -Tjpg >0-99.jpg
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Then to create 0-999 transducer :: 
Create 100-900 transducer: which appends "hundred" word after digit words :: 
fstcompile --isymbols=ascii.syms --osymbols=words.syms 100-900.txt 100-900.fst
fstdraw --isymbols=ascii.syms --osymbols=words.syms -portrait 100-900.fst | dot -Tjpg >100-900.jpg

Then take the concatenation with 100-900 with 0-99 transducer :: 
fstconcat 100-900.fst 10-99.fst | fstrmepsilon | fstdeterminize | fstminimize >0-999_3_digit_only.fst
fstunion 0-99.fst 0-999_3_digit_only.fst | fstrmepsilon | fstdeterminize | fstminimize >0-999.fst
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

To create 0-999999 transducer ::
First create "thousand" word transducer.. then concatenate 1-999 transducer with it and 0-999 transducer..

fstcompile --isymbols=ascii.syms --osymbols=words.syms thousand.txt thousand.fst

1-999 transducer :: 
fstcompile --isymbols=ascii.syms --osymbols=words.syms 1-9_only.txt 1-9_only.fst 
fstunion 1-9_only.fst 10-19.fst  |  fstrmepsilon | fstdeterminize | fstminimize >1-19.fst
fstunion 1-19.fst 20-99.fst  |  fstrmepsilon | fstdeterminize | fstminimize >1-99.fst
fstconcat 100-900.fst 10-99.fst | fstrmepsilon | fstdeterminize | fstminimize >0-999_3_digit_only.fst
fstunion 1-99.fst 0-999_3_digit_only.fst | fstrmepsilon | fstdeterminize | fstminimize >1-999.fst
_________________________________________________________________________________________________________
fstconcat 1-999.fst thousand.fst | fstconcat - 0-999_3_digit_only.fst | fstrmepsilon | fstdeterminize | fstminimize >0-999999_6_digits.fst
fstunion 0-999.fst 0-999999_6_digits.fst| fstrmepsilon | fstdeterminize | fstminimize >0-999999.fst
fstunion 0-999.fst 0-999999_h.fst| fstrmepsilon | fstdeterminize | fstminimize >0-999999.fst
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

0-999999999 ==>
1-999 + million + 0-999 + thousand + 0-999

fstcompile --isymbols=ascii.syms --osymbols=words.syms thousand.txt thousand.fst
fstcompile --isymbols=ascii.syms --osymbols=words.syms million.txt million.fst

fstconcat 1-999.fst million.fst |fstconcat - 0-999_3_digit_only.fst | fstconcat - thousand.fst | fstconcat - 0-999_3_digit_only.fst | fstrmepsilon | fstdeterminize | fstminimize >0-999999999_9_digits.fst

fstunion 0-999999.fst 0-999999999_9_digits.fst | fstrmepsilon | fstdeterminize | fstminimize >0-999999999.fst

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Important Commands:

fstunion 0-9.fst 10-19.fst  |  fstrmepsilon | fstdeterminize | fstminimize >0-19.fst
fstunion 0-9.fst 11-19.fst  |  fstrmepsilon | fstdeterminize | fstminimize >0-19.fst
fstunion 0-9.fst 10-19.fst  |  fstrmepsilon | fstdeterminize | fstminimize >0-19.fst
fstconcat 20-90.fst 1-9.fst | fstrmepsilon | fstdeterminize | fstminimize >20-99.fst
fstunion 0-19.fst 20-99.fst  |  fstrmepsilon | fstdeterminize | fstminimize >0-99.fst
fstcompile --isymbols=ascii.syms --osymbols=ascii.syms inputFST.txt inputFST.fst
fstcompile --isymbols=ascii.syms --osymbols=words.syms 0-9.txt 0-9.fst
fstdraw --isymbols=ascii.syms --osymbols=words.syms -portrait 0-9.fst | dot -Tjpg >0-9.jpg

fstunion 20-99.fst 10-19.fst  |  fstrmepsilon | fstdeterminize | fstminimize >10-99.fst

fstcompile --isymbols=ascii.syms --osymbols=words.syms 1-9.txt 1-9.fst
fstcompile --isymbols=ascii.syms --osymbols=words.syms 20-90.txt 20-90.fst
fstcompile --isymbols=ascii.syms --osymbols=words.syms 10-19.txt 10-19.fst
fstcompile --isymbols=ascii.syms --osymbols=words.syms 11-19.txt 11-19.fst

fstcompile --isymbols=ascii.syms --osymbols=words.syms thousand.txt thousand.fst

fstconcat 0-9.fst 0-9.fst | fstconcat - 0-9.fst | fstconcat - 0-9.fst | fstconcat - 0-9.fst | fstconcat - 0-9.fst | fstconcat - 0-9.fst | fstconcat - 0-9.fst | fstconcat - 0-9.fst | fstrmepsilon | fstdeterminize | fstminimize >9-digits.fst

fstconcat 0-999.fst thousand.fst |  fstconcat - 0-999.fst | fstrmepsilon | fstdeterminize | fstminimize >0-999999.fst
fstdraw --isymbols=ascii.syms --osymbols=words.syms -portrait 9-digits.fst | dot -Tjpg >9-digits.jpg