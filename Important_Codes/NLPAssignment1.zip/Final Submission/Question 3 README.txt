By Pramod Khare
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Question 3 : 
Create a transducer that maps numbers in the range 0 - 999,999,999 represented as digit strings to their English read form, 
e.g.:
1 -> one
1 1 -> eleven
1 1 1 -> one hundred eleven
1 1 1 1 -> one thousand one hundred eleven
1 1 1 1 1 -> eleven thousand one hundred eleven
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
TESTING :: How to test my 0-999999999 FST: 
1) First create a dummy unit-FST or FST which does nothing to its input. e.g. inputFST.txt

fstcompile --isymbols=ascii.syms --osymbols=ascii.syms inputFST.txt inputFST.fst

e.g. input FST for input 195 number would be - 
0 1 1 1
1 2 9 9
2 3 5 5
3
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
And take FST Compose inputFST with my answer FST -- to get the required output in words.

fstcompose inputFST.fst 0-999999999.fst | fstproject --project_output | fstrmepsilon | fstprint --isymbols=words.syms --osymbols=words.syms

Output for above inputFST of 195 number would be:- 
e.g. 	
0 1 one one
1 2 hundred hundred
2 3 ninety ninety
3 4 five five
4
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

How did I construct the full FST ::
		I used the parts-to-whole approach here.

		First I constructed few unique FSTs ::
		1) 0-9.FST - one to nine words
		2) 10-19.FST - ten to nineteen 
		3) 20-90.FST - twenty, thirty, ... till ninety (2 variations of this FST - one with 0:<epsilon> transition and other without)
		4) 100-900.FST for one to nine hundred (2 variations of this FST - one with 0:<epsilon> transition and other without)
		5) thousand.FST - with one <epsilon>:thousand transition
		6) million.FST - with one <epsilon>:million transition
		
		Then used fstcompile, fstunion, fstconcat, fstclosure, fstrmepsilon, fstdeterminize, fstminimize - to build bigger transducers using smaller ones.
				
		Two special transducers - 
		7) 1-9.FST used for creating 20-99.FST using 20-90 and 1-9 FSTs.
		8) 1-999 transducer - which is required while constructing 6-digit and 9-digits FST 
			(WHY - because if we append 0-999 then it create undeterministic paths output)
			For example - to create 6 digit FST using two 3- digit FST --- we use -- 
				1-999 FST ==> fstconcat with "thousand" word FST  ===> fstconcat with 0-999 FST ====> fstunion with 0-999 FST  ===> gives us ===> 6-digit FST (0-999999) 
				
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
How to construct 0-99 transducer::
	1) Construct 0-19 transducer ::
		fstunion 0-9.fst 10-19.fst  |  fstclosure | fstrmepsilon | fstdeterminize | fstminimize >0-19.fst
	2) Then construct 20-99 transducer ::  i.e. concatenate 20-90 with 1-9 transducer::. 
		fstconcat 20-90.fst 1-9.fst | fstrmepsilon | fstdeterminize | fstminimize >20-99.fst
	3) Construct 0-99 transducer - take the union with 0-19 and 20-99 to get 0-99 transducer.
		fstunion 0-19.fst 20-99.fst  |  fstclosure | fstrmepsilon | fstdeterminize | fstminimize >0-99.fst

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

How to create 0-999 transducer -  
	1) Create 100-900 transducer: which appends "hundred" word after digit words :: 
		fstcompile --isymbols=ascii.syms --osymbols=words.syms 100-900.txt 100-900.fst
	2) Then take the concatenation with 100-900 with 0-99 transducer :: 
		fstconcat 100-900.fst 10-99.fst | fstrmepsilon | fstdeterminize | fstminimize >0-999_3_digit_only.fst
	3) fstunion 0-99.fst 0-999_3_digit_only.fst | fstclosure | fstrmepsilon | fstdeterminize | fstminimize >0-999.fst
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

To create 0-999999 transducer ::
	1) First create "thousand" word transducer.. then concatenate 1-999 transducer with it and 0-999 transducer.	
		fstcompile --isymbols=ascii.syms --osymbols=words.syms thousand.txt thousand.fst
	2) 1-999 transducer - 
		a) Get 1-19 FST 
		b) Get 20-99 FST
		c) 100-900 FST and then 100-999 FST
		d) Union with 0-19 and 20-99 -- gives 0-99 FST
		e) Union with 100-999 with 0-99 FST to get 1-999 FST
	3) Now concate 1-999 with thousand FST and then with 0-999 FST = 
		fstconcat 1-999.fst thousand.fst | fstconcat - 0-999_3_digit_only.fst | fstrmepsilon | fstdeterminize | fstminimize >0-999999_6_digits.fst
		fstunion 0-999.fst 0-999999_6_digits.fst| fstclosure | fstrmepsilon | fstdeterminize | fstminimize >0-999999.fst

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

To create 0-999999999 transducer ::
	1) Similar to 6-digit FST as explained above - we will add million.FST along with thousand.FST.
	2) 0-999999999 ==> (1-999 + million + 0-999 + thousand + 0-999) Union (0-999999 FST as from above)

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Important Commands:

To compile txt FST to binary FSTs:
	1) For 0-9 FST: 
		fstcompile --isymbols=ascii.syms --osymbols=words.syms 0-9.txt 0-9.fst
	2) For 10-19 FST: 
		fstcompile --isymbols=ascii.syms --osymbols=words.syms 10-19.txt 10-19.fst
	3) For 1-9 words FST:
		fstcompile --isymbols=ascii.syms --osymbols=words.syms 1-9.txt 1-9.fst
	4) 20-90 FST:
		fstcompile --isymbols=ascii.syms --osymbols=words.syms 20-90.txt 20-90.fst
	5) million word FST:
		fstcompile --isymbols=ascii.syms --osymbols=words.syms million.txt million.fst
	6) thousand word FST:
		fstcompile --isymbols=ascii.syms --osymbols=words.syms thousand.txt thousand.fst
	7) Create 100-900 transducer: which appends "hundred" word after each digit at third place (except for zero) :: 
		fstcompile --isymbols=ascii.syms --osymbols=words.syms 100-900.txt 100-900.fst
		
fstunion 0-9.fst 10-19.fst  | fstclosure | fstrmepsilon | fstdeterminize | fstminimize >0-19.fst
fstconcat 20-90.fst 1-9.fst | fstrmepsilon | fstdeterminize | fstminimize >20-99.fst
fstunion 0-19.fst 20-99.fst  |  fstclosure | fstrmepsilon | fstdeterminize | fstminimize >0-99.fst
fstunion 20-99.fst 10-19.fst  |  fstclosure | fstrmepsilon | fstdeterminize | fstminimize >10-99.fst

1-999 transducer - 
		fstcompile --isymbols=ascii.syms --osymbols=words.syms 1-9_only.txt 1-9_only.fst 
		fstunion 1-9_only.fst 10-19.fst  |  fstclosure | fstrmepsilon | fstdeterminize | fstminimize >1-19.fst
		** Compile 20-90 FST without any 0:<epsilon> transition 
		fstconcat 20-90.fst 1-9.fst | fstrmepsilon | fstdeterminize | fstminimize >20-99.fst
		fstunion 1-19.fst 20-99.fst  |  fstclosure |  fstrmepsilon | fstdeterminize | fstminimize >1-99.fst
		** Now recompile 20-90 with 0:<epsilon> transition
		fstconcat 20-90.fst 1-9.fst | fstrmepsilon | fstdeterminize | fstminimize >20-99.fst
		fstunion 20-99.fst 10-19.fst  |  fstclosure | fstrmepsilon | fstdeterminize | fstminimize >10-99.fst
		fstconcat 100-900.fst 10-99.fst | fstrmepsilon | fstdeterminize | fstminimize >100-999_3_digit_only.fst
		fstunion 1-99.fst 100-999_3_digit_only.fst | fstclosure | fstrmepsilon | fstdeterminize | fstminimize >1-999.fst