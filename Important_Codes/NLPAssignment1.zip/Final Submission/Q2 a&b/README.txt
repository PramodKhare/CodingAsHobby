By Pramod Khare (khare.pr@husky.neu.edu)
Q2 Part a & b: Create FST unvowel.fst and revowel.fst 
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
This directory includes all the files (i.e. text representations of FST, input and output symbol table files - ascii.syms)
Following are the commands to create unvowel and revowel FSTs:

1) Compile the unvowel.txt into unvowel.fst
	fstcompile --isymbols=ascii.syms --osymbols=ascii.syms unvowel.txt unvowel.fst

2) Compose above created unvowel.fst with declaration.fst - 
	fstcompose declaration.fst unvowel.fst | fstproject --project_output | fstrmepsilon | fstprint --isymbols=ascii.syms --osymbols=ascii.syms

3) To invert the unvowel FST for inserting vowels back into declaration FST
	fstinvert unvowel.fst unvowel_invert.fst
	
4) To compose above inverted unvoweler with each of the N-gram language models to produce revowel1.fst, revowel2.fst, and so on.. where Language models are for n = 1, 2, 3, 5, and 7 as c1.fst, c2.fst, and so on... 
	fstcompose unvowel_invert.fst c1.fst revowel1.fst
	fstcompose unvowel_invert.fst c2.fst revowel2.fst
	fstcompose unvowel_invert.fst c3.fst revowel3.fst
	fstcompose unvowel_invert.fst c5.fst revowel5.fst
	fstcompose unvowel_invert.fst c7.fst revowel7.fst

5) To unvowel and revowel with a 1-gram model
	fstcompose declaration.fst unvowel.fst | fstproject --project_output | fstrmepsilon | fstcompose - revowel1.fst | \
    fstshortestpath | fstproject --project_output | fstrmepsilon | fsttopsort | \
    fstprint --isymbols=ascii.syms --osymbols=ascii.syms

6) To unvowel and revowel with a 2-gram model
	fstcompose declaration.fst unvowel.fst | fstproject --project_output | fstrmepsilon | fstcompose - revowel2.fst | \
    fstshortestpath | fstproject --project_output | fstrmepsilon | fsttopsort | \
    fstprint --isymbols=ascii.syms --osymbols=ascii.syms

	7) To unvowel and revowel with a 3-gram model
	fstcompose declaration.fst unvowel.fst | fstproject --project_output | fstrmepsilon | fstcompose - revowel3.fst | \
    fstshortestpath | fstproject --project_output | fstrmepsilon | fsttopsort | \
    fstprint --isymbols=ascii.syms --osymbols=ascii.syms

8) To unvowel and revowel with a 5-gram model
	fstcompose declaration.fst unvowel.fst | fstproject --project_output | fstrmepsilon | fstcompose - revowel5.fst | \
    fstshortestpath | fstproject --project_output | fstrmepsilon | fsttopsort | \
    fstprint --isymbols=ascii.syms --osymbols=ascii.syms

9) To unvowel and revowel with a 7-gram model
	fstcompose declaration.fst unvowel.fst | fstproject --project_output | fstrmepsilon | fstcompose - revowel7.fst | \
    fstshortestpath | fstproject --project_output | fstrmepsilon | fsttopsort | \
    fstprint --isymbols=ascii.syms --osymbols=ascii.syms
	
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Results:
Q: For each of the n-gram levels 1, 2, 3, 5, and 7, how many words have been correctly revoweled? What's wrong with n=1?

N-gram Level ------>	Correct revoweled words out of 18 words from declaration.fst
For 1 					= 		0 out of 18 
For 2 					= 		3 out of 18 
For 3 					= 		8 out of 18 
For 5 					= 		15 out of 18 
For 7 					= 		16 out of 18 

What's wrong with n=1? ==> 
Answer : It doesn't correct / revowels even a single word, because in 1-gram language model, each letter is independent of its predecessor or successor.
				 Probability to hit the character in the word all depends on its own. e.g. P(Word) = P(c1)P(c2)P(c3) .... where c1, c2, c3 are characters in that word.
				 Viewing from the whole model, the sum of all the one-state-hitting probabilities i.e. sum of all character hit probabilities should be 1.
