Assignment No 1
By Pramod Khare
NEU ID - 01910794
khare.pr@husky.neu.edu

There is a separate .txt file explaining the answer to specific question
Question 1 - Regular Expressions.txt
Question 2 a&b- Answers.txt
Question 2 c&d- Answers.txt
Question 3 README.txt

Q2 abd Q3 have separate folder which contains their specific files.

Important Links -  
http://nltk.googlecode.com/svn/trunk/nltk_data/packages/corpora/gutenberg.zip.
http://www.openfst.org/twiki/bin/view/FST/WebHome
http://www.openfst.org/twiki/bin/view/FST/FstExamples
http://www.ccs.neu.edu/course/cs6120sp13/hw1-files.zip