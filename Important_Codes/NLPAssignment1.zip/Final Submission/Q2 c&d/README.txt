By Pramod Khare (khare.pr@husky.neu.edu)
Q2 Part c & d: Create FST squash.fst and revowel.fst - where unvoweling will not remove first and last vowels from the words 
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
This directory includes all the files (i.e. text representations of FST, input and output symbol table files - ascii.syms)
Following are the commands to create squash and revowel FSTs:

1) Compile the squash.txt into squash.fst
	fstcompile --isymbols=ascii.syms --osymbols=ascii.syms squash.txt squash.fst

2) Compose above created squash.fst with declaration.fst - 
	fstcompose declaration.fst squash.fst | fstproject --project_output | fstrmepsilon | fstprint --isymbols=ascii.syms --osymbols=ascii.syms

3) To invert the squash FST for inserting vowels back into declaration FST
	fstinvert squash.fst squash_invert.fst
	
4) To compose above inverted unvoweler with each of the N-gram language models to produce revowel1.fst, revowel2.fst, and so on.. where Language models are for n = 1, 2, 3, 5, and 7 as c1.fst, c2.fst, and so on... 
	fstcompose squash_invert.fst c1.fst revowel1.fst
	fstcompose squash_invert.fst c2.fst revowel2.fst
	fstcompose squash_invert.fst c3.fst revowel3.fst
	fstcompose squash_invert.fst c5.fst revowel5.fst
	fstcompose squash_invert.fst c7.fst revowel7.fst

5) To unvowel and revowel with a 1-gram model
	fstcompose declaration.fst squash.fst | fstproject --project_output | fstrmepsilon | fstcompose - revowel1.fst | \
    fstshortestpath | fstproject --project_output | fstrmepsilon | fsttopsort | \
    fstprint --isymbols=ascii.syms --osymbols=ascii.syms

6) To unvowel and revowel with a 2-gram model
	fstcompose declaration.fst squash.fst | fstproject --project_output | fstrmepsilon | fstcompose - revowel2.fst | \
    fstshortestpath | fstproject --project_output | fstrmepsilon | fsttopsort | \
    fstprint --isymbols=ascii.syms --osymbols=ascii.syms

	7) To unvowel and revowel with a 3-gram model
	fstcompose declaration.fst squash.fst | fstproject --project_output | fstrmepsilon | fstcompose - revowel3.fst | \
    fstshortestpath | fstproject --project_output | fstrmepsilon | fsttopsort | \
    fstprint --isymbols=ascii.syms --osymbols=ascii.syms

8) To unvowel and revowel with a 5-gram model
	fstcompose declaration.fst squash.fst | fstproject --project_output | fstrmepsilon | fstcompose - revowel5.fst | \
    fstshortestpath | fstproject --project_output | fstrmepsilon | fsttopsort | \
    fstprint --isymbols=ascii.syms --osymbols=ascii.syms

9) To unvowel and revowel with a 7-gram model
	fstcompose declaration.fst squash.fst | fstproject --project_output | fstrmepsilon | fstcompose - revowel7.fst | \
    fstshortestpath | fstproject --project_output | fstrmepsilon | fsttopsort | \
    fstprint --isymbols=ascii.syms --osymbols=ascii.syms

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Results:
Q: For each of the n-gram levels 1, 2, 3, 5, and 7, how many words have been correctly revoweled? What's wrong with n=1?

N-gram Level ------>	Correct revoweled words out of 18 words from declaration.fst
For 1 					= 		7 out of 18 
For 2 					= 		9 out of 18 
For 3 					= 		10 out of 18 
For 5 					= 		17 out of 18 
For 7 					= 		17 out of 18 
